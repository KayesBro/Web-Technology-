let sign;
let text1='';

function cancle(){
	document.getElementById("output").innerHTML="";
	
}
function del(){
	
	
}
function mul(){
	
	let min=document.getElementById("output").innerHTML="*";
	text1+=min;
}
function divide(){
	
	let min=document.getElementById("output").innerHTML="/";
	text1+=min;
}
function one(){
	document.getElementById("output").innerHTML="1";
	text1+=1;
	
}
function two(){
	document.getElementById("output").innerHTML="2";
	text1+=2;
	
}
function three(){
	document.getElementById("output").innerHTML="3";
	text1+=3;
	
}
function plus(){
	
	let add=document.getElementById("output").innerHTML="+";
	text1+=add;
}
function four(){
	document.getElementById("output").innerHTML="4";
	text1+=4;
	
}
function five(){
	document.getElementById("output").innerHTML="5";
	text1+=5;
	
}
function six(){
	document.getElementById("output").innerHTML="6";
	text1+=6;
	
}
function minius(){
	let min=document.getElementById("output").innerHTML="-";
	text1+=min;
	
}
function seven(){
	document.getElementById("output").innerHTML="7";
	text1+=7;
	
}
function eight(){
	document.getElementById("output").innerHTML="8";
	text1+=8;
	
}
function nine(){
	document.getElementById("output").innerHTML="9";
	text1+=9;
	
}
function percentage(){
	
	let min=document.getElementById("output").innerHTML="%";
	text1+=min;
}
function zero(){
	document.getElementById("output").innerHTML="0";
	text1+=0;
	
}
function dot(){
	let d = document.getElementById("output").innerHTML=".";
	text1+=d;
	
}
function equal(){
	// let text=document.getElementById("textBox").value;
	// let result;
	// let len;
	// let firstDig='';
	// let lastDig='';
	// for(let i=0;i<text.length;i++)
	// {
	// 	if(text[i]=='+' || text[i]=='-' || text[i]=='*' || text[i]=='/' || text[i]=='%')
	// 	{
	// 		len=i;
	// 	}
	// }
	// for(let i=0;i<len;i++)
	// {
	// 	firstDig+=text[i];
	// }
	// for(let i=len+1;i<text.length;i++)
	// {
	// 	lastDig+=text[i];
	// }
	// let firstDigit=Number(firstDig);
	// let lastDigit=Number(lastDig);

	// if(text[len]=='+'){
	// 	result=firstDigit + lastDigit;
	// 	sign="+";
	// }
	// else if(text[len]=='-'){
	// 	result=firstDigit - lastDigit;
	// 	sign="-";
	// }
	// else if(text[len]=='*'){
	// 	result=firstDigit * lastDigit;
	// 	sign="*";
	// }
	// else if(text[len]=='/'){
	// 	result=firstDigit / lastDigit;
	// 	sign="/";
	// }
	// else if(text[len]=='%'){
	// 	result=firstDigit % lastDigit;
	// 	sign="%";
	// }
	// else
	// {
	// 	result="Enter Correct Syntax";
	// }
	// document.getElementById("output").innerHTML=firstDigit+ " " + sign + " " + lastDigit +" = " + result;
	// //document.getElementById("output").innerHTML=text;
	// 
	//=document.getElementById("textBox").value;
	let result1;
	let len1;
	let firstDig1='';
	let lastDig1='';
	for(let i=0;i<text1.length;i++)
	{
		if(text1[i]=='+' || text1[i]=='-' || text1[i]=='*' || text1[i]=='/' || text1[i]=='%')
		{
			len1=i;
		}
	}
	for(let i=0;i<len1;i++)
	{
		firstDig1+=text1[i];
	}
	for(let i=len1+1;i<text1.length;i++)
	{
		lastDig1+=text1[i];
	}
	let firstDigit1=Number(firstDig1);
	let lastDigit1=Number(lastDig1);

	if(text1[len1]=='+'){
		result1=firstDigit1 + lastDigit1;
		sign="+";
	}
	else if(text1[len1]=='-'){
		result1=firstDigit1 - lastDigit1;
		sign="-";
	}
	else if(text1[len1]=='*'){
		result1=firstDigit1 * lastDigit1;
		sign="*";
	}
	else if(text1[len1]=='/'){
		result1=firstDigit1 / lastDigit1;
		sign="/";
	}
	else if(text1[len1]=='%'){
		result1=firstDigit1 % lastDigit1;
		sign="%";
	}
	else
	{
		result1="Enter Correct Syntax";
	}
	document.getElementById("output").innerHTML=firstDigit1+ " " + sign + " " + lastDigit1 +" = " + result1;
	//document.getElementById("output").innerHTML=text;
}


