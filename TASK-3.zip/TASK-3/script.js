function showMemberCard(name,age,email,phn,mem){

let sec=[
		"A",
		"B",
		"C",
		];
		for(let i=0;i<sec.length;i++)
		{
			console.log(sec[i]);
		}

    let fee,mShip;
    if (mem === "b") {
        fee = 500;
		mShip="Basic";
    } else if (mem === "s") {
        fee = 1000;
		mShip="Silver";
    } else {
        fee = 1500;
		mShip="Gold";
    }





	document.getElementById("output").innerHTML=
	"<h2>Members Information</h2>" +
	"Name: "+name+"<br>"+
	"Age: "+age+"<br>"+
	"Email: "+email+"<br>"+
	"Phone: "+phn+"<br>"+
	"Member Ship: "+mShip+"<br><br>"+
	"category: "+(age<13 ? "Junior" : "Regular")+"<br>"+
	"Applicable Fee: "+ fee +"<br>"+
	"<b>Sections: </b><br>"+
	sec.join("<br>");
	
}
document.addEventListener("submit",function (event){
	event.preventDefault();
	let name=
		document.getElementById("name").value;
		
	let age=
		document.getElementById("age").value;
		
	let email=
		document.getElementById("email").value;
		
	let phn=
		document.getElementById("phn").value;
		
	let mem=
		document.querySelector(
			'input[name="mem"]:checked'
				).value;
				
	showMemberCard(
		name,
		age,
		email,
		phn,
		mem
		);
});
		
		
		
		
		
		
		
		